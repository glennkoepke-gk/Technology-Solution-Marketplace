from docx import Document
import json, re, pathlib
p=pathlib.Path('/mnt/data/eBook: Facility Tech Solution Marketplace.docx')
D=Document(p)
para=[p.text.strip() for p in D.paragraphs]
CAT=[
 dict(id='camera-vision', name='Camera vision', short='AI-powered recognition at every gate', eyebrow='Capture & verification', icon='scan-line', number='01',color='#ff6b46', start=66, stop=87, heads=[67,70,73,75,78,81,83,85],matrix=0, intro='Convert live camera feeds into usable trailer, truck, container, and inspection data. Integrate those signals with your gate and yard workflows.', stage='Gate', outcomes=['automate','secure','visibility']),
 dict(id='yard-trucks', name='Yard trucks', short='Electrify and connect trailer movements', eyebrow='Movement & powertrains', icon='truck', number='02', color='#cc89ff', start=89, stop=110,heads=[91,93,95,97,99,101,103,106,108],matrix=1, intro=para[90], stage='Yard', outcomes=['flow','autonomy']),
 dict(id='autonomous-yard-trucks', name='Autonomous yard trucks',short='Driverless moves inside the fence',eyebrow='Yard autonomy', icon='route',number='03',color='#7bb4ff',start=114,stop=137,heads=[115,118,121,124,127,130,133],matrix=2,intro='Autonomous tractors combine vehicle sensors, navigation, and yard commands to move trailers within a controlled facility. Safety validation, air-line connection and operational maturity vary.', stage='Yard',outcomes=['autonomy','flow']),
 dict(id='autonomous-class-8',name='Autonomous Class 8',short='Prepare for driverless highway freight',eyebrow='Autonomous transportation',icon='move-right',number='04',color='#f4b35c',start=141,stop=162,heads=[143,146,149,152,155,159],matrix=3,intro=para[142],stage='Transportation',outcomes=['autonomy','flow']),
 dict(id='gate-arms',name='Gate arms',short='Control physical entry and exit',eyebrow='Physical automation',icon='barrier',number='05',color='#6ccbbd',start=164,stop=178,heads=[165,167,169,171,173,175],matrix=None,intro=para[37],stage='Gate',outcomes=['automate','secure']),
 dict(id='intercoms',name='Intercoms',short='Speak to drivers without the guard window',eyebrow='Driver engagement',icon='radio',number='06',color='#e38ec7',start=178,stop=197,heads=[179,181,183,185,187,189,191],matrix=4,intro=para[40],stage='Gate',outcomes=['automate','experience']),
 dict(id='access-control',name='Access control',short='Verify credentials before the barrier lifts',eyebrow='Physical security',icon='shield-check',number='07',color='#90d78f',start=197,stop=219,heads=[198,200,202,204,206,208,210,212,214,217],matrix=None,intro='Access control connects identities, credentials, door systems, and gate controllers to determine who can enter a facility and to preserve an audit trail.',stage='Perimeter',outcomes=['secure','automate']),
 dict(id='camera-providers',name='Camera providers',short='See the whole operation, not just the plate',eyebrow='Security infrastructure',icon='video',number='08',color='#9aa9fb',start=219,stop=241,heads=[220,223,225,227,229,231,233,235,237],matrix=None,intro=para[21],stage='Perimeter',outcomes=['secure','visibility']),
 dict(id='remote-guarding',name='Remote guarding',short='Human intervention backed by live video',eyebrow='Managed security',icon='eye',number='09',color='#e8af78',start=241,stop=260,heads=[242,245,247,250,252],matrix=None,intro='Remote operators use live or event-triggered video to investigate incidents, intervene via speakers, and escalate security situations.',stage='Perimeter',outcomes=['secure']),
 dict(id='ebol-digital-gate',name='eBOL + digital gate',short='Connect drivers, documents, gate, and yard',eyebrow='Connected workflows',icon='file-check',number='10',color='#fb8667',start=260,stop=265,heads=[261],matrix=None,intro=para[262],stage='Gate + Dock',outcomes=['automate','experience','flow'])
]
clean={'ATAI.ai':'ATAI','Outpost.us':'Outpost','Renaissant.com':'Renaissant','Ex9':'ex9','Fernride':'FERNRIDE','Worlds.io':'Worlds.io'}
def slug(x):
 return re.sub('-+', '-',re.sub(r'[^a-z0-9]+','-',x.lower())).strip('-')
vendors=[]
for c in CAT:
 for n,j in enumerate(c['heads']):
  name=para[j].strip(' :\t')
  name=clean.get(name,name)
  nxt=c['heads'][n+1] if n+1<len(c['heads']) else c['stop']
  # omit section introductions, matrices, evaluation matrix blurbs after entries
  contents=[]
  for k in range(j+1,nxt):
   t=para[k]
   if not t: continue
   if 'Capability Matrix' in t or (len(t)<110 and t.lower().startswith('the matrix below')): break
   if k in (239,240): break
   if k>=263 and c['id']=='ebol-digital-gate': break
   contents.append(t)
  body=' '.join(contents)
  if not body:
   print('NO BODY',name,j)
  keys=['AI','computer vision','electric','diesel','autonomous','retrofit','QR','remote','cloud','mobile','lidar','edge','camera','identity','security','verification','container','integration','robotic','charging','video','solar','multilingual']
  tag_names={'AI':'AI','computer vision':'Computer vision','electric':'Electric','diesel':'Diesel','autonomous':'Autonomous','retrofit':'Retrofit','QR':'QR access','remote':'Remote operations','cloud':'Cloud','mobile':'Mobile','lidar':'LiDAR','edge':'Edge compute','camera':'Cameras','identity':'Identity','security':'Security','verification':'Verification','container':'Container tracking','integration':'Integrations','robotic':'Robotics','charging':'Charging','video':'Video','solar':'Solar','multilingual':'Multilingual'}
  matches=[tag_names[k] for k in keys if re.search(r'\b'+re.escape(k)+r'\b',body,re.I)]
  summary=contents[0].strip() if contents else 'Read the source profile for details.'
  summary=re.sub(r'\s+',' ',summary)
  m=re.match(r'^(.{80,210}?[.!?])(?:\s|$)',summary)
  summary=m.group(1) if m else (summary[:180].rsplit(' ',1)[0].rstrip('.,;')+'…' if len(summary)>185 else summary)
  vendors.append(dict(id=c['id']+'--'+slug(name),name=name,categoryId=c['id'],description=summary,paragraphs=contents,tags=matches[:4],sourceSection=c['name'],sourceParagraph=j))
matrices=[]
for n,t in enumerate(D.tables):
 c=CAT[[x['matrix'] for x in CAT].index(n)]
 rows=[[re.sub(r'\s+',' ',cell.text).strip() for cell in row.cells] for row in t.rows]
 matrices.append(dict(id=c['id'],categoryId=c['id'],title=c['name']+' comparison',columns=rows[0],rows=rows[1:]))
# append evaluation notes by matching name where feasible
for v in vendors:
 matrix=next((m for m in matrices if m['categoryId']==v['categoryId']),None)
 if matrix:
  for r in matrix['rows']:
   nn=re.sub(r'[^a-z0-9]','',r[0].lower())
   vn=re.sub(r'[^a-z0-9]','',v['name'].lower())
   if nn==vn or nn.startswith(vn) or vn.startswith(nn):
    v['matrix']=dict(zip(matrix['columns'][1:],r[1:]))
    break
for c in CAT:
 c['count']=len([v for v in vendors if v['categoryId']==c['id']]); c.pop('start');c.pop('stop');c.pop('heads');c.pop('matrix')
data=dict(title='Facility Tech Solution Marketplace',edition='October 2026',subtitle='An independent field guide to the facility of the future',intro=[para[i] for i in range(11,16)], fundamentals=[dict(title=para[h].rstrip(':'),text=' '.join(para[k] for k in range(h+1,end) if para[k])) for h,end in [(20,22),(22,34),(34,36),(36,38),(39,41),(41,43),(43,45),(45,47),(47,49),(49,51),(51,54),(54,58)]],categories=CAT,vendors=vendors,matrices=matrices,conclusion=para[263],lastNote=para[264],source='Adapted from the supplied eBook manuscript. Vendor capabilities and industry claims are presented as described there; no independent verification is implied.')
out=pathlib.Path('/mnt/data/facility-tech-marketplace/data')
(out/'catalog.json').write_text(json.dumps(data,indent=2,ensure_ascii=False))
(out/'catalog.js').write_text('window.FACILITY_MARKETPLACE_DATA = '+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n')
print('vendors',len(vendors),'categories',len(CAT),'matrix rows',sum(len(m['rows']) for m in matrices))
for c in CAT: print(c['name'],c['count'])
print('unmatched matrix',[(v['name'],v['categoryId']) for v in vendors if v['categoryId'] in [m['categoryId'] for m in matrices] and 'matrix' not in v])
print('text size',sum(len(' '.join(v['paragraphs'])) for v in vendors))
