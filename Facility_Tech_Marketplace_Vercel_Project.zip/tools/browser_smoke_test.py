"""Developer-only test. Validates the static experience using in-memory browser assets.
Run with: python tools/browser_smoke_test.py
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import base64
ROOT=Path(__file__).resolve().parent.parent
html=(ROOT/'index.html').read_text()
for tag in ['<link rel="stylesheet" href="styles.css">','<script defer src="data/catalog.js"></script>','<script defer src="app.js"></script>']:
    html=html.replace(tag,'')
svg='data:image/svg+xml;base64,'+base64.b64encode((ROOT/'assets/facility-hero.svg').read_bytes()).decode()
html=html.replace('assets/facility-hero.svg',svg)
css='\n'.join((ROOT/'styles.css').read_text().splitlines()[1:])
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1,accept_downloads=True)
    errors=[]
    page.on('pageerror',lambda err: errors.append(str(err)))
    page.set_content(html,wait_until='domcontentloaded')
    page.add_style_tag(content=css)
    page.add_script_tag(content=(ROOT/'data/catalog.js').read_text())
    page.add_script_tag(content=(ROOT/'app.js').read_text())
    assert page.locator('.vendor-card').count()==12
    assert page.locator('#result-count').inner_text()=='68 results'
    page.locator('#vendor-search').fill('Outrider')
    assert page.locator('.vendor-card').count()>=1
    page.locator('#vendor-search').fill('')
    page.locator('[data-category="camera-vision"]').first.click()
    assert page.locator('#result-count').inner_text()=='8 results'
    page.locator('#vendor-sort').select_option('name')
    assert page.locator('.vendor-card h4').first.inner_text()=='ATAI'
    page.locator('.vendor-card [data-save]').first.click()
    assert page.locator('#saved-count').inner_text()=='1'
    page.locator('.vendor-card [data-open]').first.click()
    assert page.locator('#drawer').is_visible()
    assert 'ATAI' in page.locator('#drawer .drawer-heading').inner_text()
    page.locator('.drawer-close').click()
    assert page.locator('#drawer').is_hidden()
    page.locator('.vendor-card [data-compare]').first.click()
    page.locator('.vendor-card [data-compare]').nth(1).click()
    assert page.locator('.compare-bar').is_visible()
    page.locator('[data-open-compare]').click()
    assert page.locator('#drawer').is_visible()
    assert page.locator('.compare-table th').count() == 3
    with page.expect_download() as d:
        page.locator('[data-export="compare"]').click()
    assert d.value.suggested_filename.endswith('.csv')
    page.locator('.drawer-close').click()
    page.locator('[data-matrix="yard-trucks"]').click()
    assert 'Yard trucks' in page.locator('#matrix-title').inner_text()
    page.locator('[data-zone="yard"]').click()
    assert 'connected yard' in page.locator('#blueprint-detail h3').inner_text().lower()
    page.evaluate('window.scrollTo(0,0)')
    page.wait_for_timeout(100)
    page.screenshot(path=str(ROOT/'desktop-preview.png'),full_page=True)
    page.set_viewport_size({'width':390,'height':844})
    page.evaluate('window.scrollTo(0,0)')
    page.wait_for_timeout(200)
    page.screenshot(path=str(ROOT/'mobile-preview.png'),full_page=True)
    width=page.evaluate('({client:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth})')
    print('Desktop and mobile screenshot saved. Mobile width:',width)
    assert width['scroll']==width['client'], 'Horizontal overflow at mobile viewport'
    assert not errors, errors
    print('PASS: search, category, sort, save, profile, compare, CSV, matrices, hotspots, mobile layout, browser errors.')
    browser.close()
